var localizedStrings = new Object;

localizedStrings["Hello, World!"] = 'UNIX/Linux Permissions';
localizedStrings["Done"] = "Done";
localizedStrings[''] = '- UNIX/Linux Permissions Professor';
localizedStrings['ChmodPro'] = 'ChmodPro';
